"use client"

import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { CheckCircle2, Package, Mail, ArrowRight } from "lucide-react"
import Link from "next/link"

export default function OrderConfirmationPage() {
  const orderNumber = "ORD-" + Math.random().toString(36).substr(2, 9).toUpperCase()

  return (
    <div className="min-h-screen">
      <Header />
      <main className="container mx-auto px-4 py-16">
        <Card className="mx-auto max-w-2xl">
          <CardContent className="p-8 text-center">
            <div className="mb-6 flex justify-center">
              <div className="flex h-20 w-20 items-center justify-center rounded-full bg-green-100">
                <CheckCircle2 className="h-10 w-10 text-green-600" />
              </div>
            </div>

            <h1 className="mb-3 text-3xl font-bold text-balance">Order Confirmed!</h1>
            <p className="mb-6 text-lg text-muted-foreground text-pretty">
              Thank you for your purchase. Your order has been successfully placed.
            </p>

            <div className="mb-8 rounded-lg bg-muted p-4">
              <p className="mb-1 text-sm text-muted-foreground">Order Number</p>
              <p className="text-xl font-bold">{orderNumber}</p>
            </div>

            <div className="mb-8 grid gap-4 sm:grid-cols-2">
              <div className="flex flex-col items-center rounded-lg border bg-card p-4">
                <Mail className="mb-3 h-8 w-8 text-primary" />
                <h3 className="mb-1 font-semibold">Confirmation Email</h3>
                <p className="text-sm text-muted-foreground text-center leading-relaxed">
                  Check your email for order details and tracking information
                </p>
              </div>
              <div className="flex flex-col items-center rounded-lg border bg-card p-4">
                <Package className="mb-3 h-8 w-8 text-primary" />
                <h3 className="mb-1 font-semibold">Estimated Delivery</h3>
                <p className="text-sm text-muted-foreground text-center leading-relaxed">
                  Your order will arrive in 3-5 business days
                </p>
              </div>
            </div>

            <div className="flex flex-col gap-3 sm:flex-row sm:justify-center">
              <Button asChild size="lg" className="group">
                <Link href="/track-order">
                  Track Your Order
                  <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
                </Link>
              </Button>
              <Button asChild variant="outline" size="lg" className="bg-transparent">
                <Link href="/products">Continue Shopping</Link>
              </Button>
            </div>
          </CardContent>
        </Card>
      </main>
      <Footer />
    </div>
  )
}
