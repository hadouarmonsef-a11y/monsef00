"use client"

import type React from "react"

import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Package, Search, CheckCircle2, Truck, Home } from "lucide-react"
import { useState } from "react"

const mockOrderData = {
  orderId: "ORD-A1B2C3D4E",
  orderDate: "January 15, 2025",
  estimatedDelivery: "January 20, 2025",
  status: "In Transit",
  currentLocation: "New York Distribution Center",
  trackingSteps: [
    {
      status: "Order Placed",
      description: "Your order has been confirmed",
      date: "Jan 15, 2:30 PM",
      completed: true,
    },
    {
      status: "Processing",
      description: "Your order is being prepared",
      date: "Jan 15, 4:15 PM",
      completed: true,
    },
    {
      status: "Shipped",
      description: "Your order has been shipped",
      date: "Jan 16, 10:00 AM",
      completed: true,
    },
    {
      status: "In Transit",
      description: "Package is on the way",
      date: "Jan 17, 8:30 AM",
      completed: true,
    },
    {
      status: "Out for Delivery",
      description: "Package will be delivered today",
      date: "Pending",
      completed: false,
    },
    {
      status: "Delivered",
      description: "Package delivered successfully",
      date: "Pending",
      completed: false,
    },
  ],
  items: [
    {
      name: "Premium Silicone Case",
      quantity: 2,
      price: 29.99,
      image:
        "https://placehold.co/100x100?text=Premium+matte+black+silicone+phone+case+with+camera+protection+modern+minimal+design",
    },
    {
      name: "Wireless Charging Pad",
      quantity: 1,
      price: 49.99,
      image: "https://placehold.co/100x100?text=Sleek+white+circular+wireless+charging+pad+with+LED+indicator+top+view",
    },
  ],
}

export default function TrackOrderPage() {
  const [orderNumber, setOrderNumber] = useState("")
  const [email, setEmail] = useState("")
  const [tracking, setTracking] = useState<typeof mockOrderData | null>(null)

  const handleTrack = (e: React.FormEvent) => {
    e.preventDefault()
    if (orderNumber && email) {
      setTracking(mockOrderData)
    }
  }

  return (
    <div className="min-h-screen">
      <Header />
      <main className="container mx-auto px-4 py-8">
        <h1 className="mb-8 text-3xl font-bold tracking-tight text-balance">Track Your Order</h1>

        {!tracking ? (
          <Card className="mx-auto max-w-2xl">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Package className="h-5 w-5" />
                Enter Order Details
              </CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleTrack} className="space-y-4">
                <div>
                  <Label htmlFor="orderNumber">Order Number</Label>
                  <Input
                    id="orderNumber"
                    placeholder="ORD-XXXXXXXXX"
                    value={orderNumber}
                    onChange={(e) => setOrderNumber(e.target.value)}
                    required
                  />
                  <p className="mt-1 text-sm text-muted-foreground">
                    You can find this in your order confirmation email
                  </p>
                </div>
                <div>
                  <Label htmlFor="email">Email Address</Label>
                  <Input
                    id="email"
                    type="email"
                    placeholder="your@email.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required
                  />
                </div>
                <Button type="submit" className="w-full gap-2">
                  <Search className="h-4 w-4" />
                  Track Order
                </Button>
              </form>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-6">
            {/* Order Summary */}
            <Card>
              <CardContent className="p-6">
                <div className="mb-6 grid gap-4 sm:grid-cols-3">
                  <div>
                    <p className="text-sm text-muted-foreground">Order Number</p>
                    <p className="font-semibold">{tracking.orderId}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Order Date</p>
                    <p className="font-semibold">{tracking.orderDate}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Estimated Delivery</p>
                    <p className="font-semibold">{tracking.estimatedDelivery}</p>
                  </div>
                </div>

                <div className="rounded-lg bg-primary/10 p-4">
                  <div className="flex items-center gap-3">
                    <Truck className="h-8 w-8 text-primary" />
                    <div>
                      <p className="font-semibold">{tracking.status}</p>
                      <p className="text-sm text-muted-foreground">{tracking.currentLocation}</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Tracking Timeline */}
            <Card>
              <CardHeader>
                <CardTitle>Tracking History</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="relative space-y-6">
                  {tracking.trackingSteps.map((step, index) => (
                    <div key={index} className="relative flex gap-4">
                      {/* Timeline line */}
                      {index < tracking.trackingSteps.length - 1 && (
                        <div
                          className={`absolute left-5 top-12 h-full w-0.5 ${step.completed ? "bg-primary" : "bg-border"}`}
                        />
                      )}

                      {/* Icon */}
                      <div
                        className={`relative flex h-10 w-10 shrink-0 items-center justify-center rounded-full border-2 ${
                          step.completed
                            ? "border-primary bg-primary text-primary-foreground"
                            : "border-border bg-background"
                        }`}
                      >
                        {step.completed ? (
                          <CheckCircle2 className="h-5 w-5" />
                        ) : index === tracking.trackingSteps.findIndex((s) => !s.completed) ? (
                          <Truck className="h-5 w-5 text-muted-foreground" />
                        ) : (
                          <Home className="h-5 w-5 text-muted-foreground" />
                        )}
                      </div>

                      {/* Content */}
                      <div className="flex-1 pb-8">
                        <p className={`font-semibold ${step.completed ? "" : "text-muted-foreground"}`}>
                          {step.status}
                        </p>
                        <p className="text-sm text-muted-foreground">{step.description}</p>
                        <p className="mt-1 text-xs text-muted-foreground">{step.date}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Order Items */}
            <Card>
              <CardHeader>
                <CardTitle>Order Items</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {tracking.items.map((item, index) => (
                  <div key={index} className="flex gap-4 border-b pb-4 last:border-0 last:pb-0">
                    <div className="h-20 w-20 shrink-0 overflow-hidden rounded-lg border">
                      <img
                        src={item.image || "/placeholder.svg"}
                        alt={item.name}
                        className="h-full w-full object-cover"
                      />
                    </div>
                    <div className="flex-1">
                      <p className="font-semibold">{item.name}</p>
                      <p className="text-sm text-muted-foreground">Quantity: {item.quantity}</p>
                      <p className="text-sm font-medium">${item.price}</p>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>

            <Button variant="outline" onClick={() => setTracking(null)} className="w-full bg-transparent">
              Track Another Order
            </Button>
          </div>
        )}
      </main>
      <Footer />
    </div>
  )
}
