import type React from "react"
import type { Metadata } from "next"
import { Geist, Geist_Mono } from "next/font/google"
import { Analytics } from "@vercel/analytics/next"
import { Toaster } from "@/components/ui/toaster"
import "./globals.css"

const _geist = Geist({ subsets: ["latin"] })
const _geistMono = Geist_Mono({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "MobileHub - Premium Mobile Accessories",
  description:
    "Shop the best collection of mobile phone accessories including cases, chargers, earphones, power banks, and more. Fast delivery and secure payment.",
  keywords: "mobile accessories, phone cases, chargers, earphones, power banks, wireless charging, mobile holders",
  openGraph: {
    title: "MobileHub - Premium Mobile Accessories",
    description: "Your one-stop shop for quality mobile accessories",
    type: "website",
  },
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en">
      <body className={`font-sans antialiased`}>
        {children}
        <Toaster />
        <Analytics />
      </body>
    </html>
  )
}
