"use client"

import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { ProductCard } from "@/components/product-card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Checkbox } from "@/components/ui/checkbox"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet"
import { Slider } from "@/components/ui/slider"
import { SlidersHorizontal } from "lucide-react"
import { useState, useMemo } from "react"
import { useSearchParams } from "next/navigation"

// Extended mock products data
const allProducts = [
  {
    id: "1",
    name: "Premium Silicone Case",
    price: 29.99,
    originalPrice: 39.99,
    image:
      "https://placehold.co/400x400?text=Premium+matte+black+silicone+phone+case+with+camera+protection+modern+minimal+design",
    rating: 4.8,
    reviews: 324,
    category: "cases",
    inStock: true,
  },
  {
    id: "2",
    name: "Wireless Charging Pad",
    price: 49.99,
    image: "https://placehold.co/400x400?text=Sleek+white+circular+wireless+charging+pad+with+LED+indicator+top+view",
    rating: 4.6,
    reviews: 189,
    category: "chargers",
    inStock: true,
  },
  {
    id: "3",
    name: "True Wireless Earbuds",
    price: 79.99,
    originalPrice: 99.99,
    image:
      "https://placehold.co/400x400?text=Modern+black+wireless+earbuds+with+charging+case+premium+quality+on+white+background",
    rating: 4.9,
    reviews: 567,
    category: "audio",
    inStock: true,
    badge: "Bestseller",
  },
  {
    id: "4",
    name: "20000mAh Power Bank",
    price: 59.99,
    image:
      "https://placehold.co/400x400?text=Compact+gray+portable+power+bank+with+dual+USB+ports+LED+display+professional",
    rating: 4.7,
    reviews: 412,
    category: "power-banks",
    inStock: true,
  },
  {
    id: "5",
    name: "USB-C Fast Charging Cable",
    price: 19.99,
    image:
      "https://placehold.co/400x400?text=Braided+black+USB+C+charging+cable+coiled+on+white+surface+durable+premium",
    rating: 4.5,
    reviews: 298,
    category: "cables",
    inStock: true,
  },
  {
    id: "6",
    name: "Magnetic Car Mount",
    price: 24.99,
    image: "https://placehold.co/400x400?text=Sleek+black+magnetic+car+phone+holder+with+adjustable+arm+modern+design",
    rating: 4.6,
    reviews: 156,
    category: "accessories",
    inStock: true,
  },
  {
    id: "7",
    name: "Tempered Glass Screen Protector",
    price: 14.99,
    image:
      "https://placehold.co/400x400?text=Clear+tempered+glass+screen+protector+with+installation+kit+professional+quality",
    rating: 4.4,
    reviews: 523,
    category: "accessories",
    inStock: true,
  },
  {
    id: "8",
    name: "Bluetooth Speaker",
    price: 69.99,
    originalPrice: 89.99,
    image:
      "https://placehold.co/400x400?text=Compact+cylindrical+waterproof+bluetooth+speaker+in+matte+black+modern+style",
    rating: 4.8,
    reviews: 234,
    category: "audio",
    inStock: true,
    badge: "New",
  },
  {
    id: "9",
    name: "Leather Wallet Case",
    price: 39.99,
    image: "https://placehold.co/400x400?text=Premium+brown+leather+wallet+phone+case+with+card+slots+elegant+design",
    rating: 4.7,
    reviews: 289,
    category: "cases",
    inStock: true,
  },
  {
    id: "10",
    name: "65W GaN Charger",
    price: 54.99,
    image: "https://placehold.co/400x400?text=Compact+white+GaN+fast+charger+with+multiple+ports+modern+minimalist",
    rating: 4.8,
    reviews: 401,
    category: "chargers",
    inStock: true,
    badge: "New",
  },
  {
    id: "11",
    name: "Noise Cancelling Headphones",
    price: 149.99,
    originalPrice: 199.99,
    image:
      "https://placehold.co/400x400?text=Premium+over+ear+wireless+headphones+with+active+noise+cancellation+black",
    rating: 4.9,
    reviews: 678,
    category: "audio",
    inStock: true,
    badge: "Bestseller",
  },
  {
    id: "12",
    name: "10000mAh Slim Power Bank",
    price: 39.99,
    image: "https://placehold.co/400x400?text=Ultra+thin+aluminum+power+bank+with+digital+display+space+gray",
    rating: 4.6,
    reviews: 234,
    category: "power-banks",
    inStock: true,
  },
  {
    id: "13",
    name: "Braided Lightning Cable",
    price: 24.99,
    image: "https://placehold.co/400x400?text=Durable+nylon+braided+lightning+cable+in+gray+with+aluminum+connectors",
    rating: 4.5,
    reviews: 412,
    category: "cables",
    inStock: true,
  },
  {
    id: "14",
    name: "Phone Ring Stand",
    price: 12.99,
    image: "https://placehold.co/400x400?text=360+degree+rotating+metal+phone+ring+holder+with+kickstand+silver",
    rating: 4.3,
    reviews: 189,
    category: "accessories",
    inStock: true,
  },
  {
    id: "15",
    name: "Rugged Armor Case",
    price: 34.99,
    image: "https://placehold.co/400x400?text=Heavy+duty+protective+phone+case+with+kickstand+military+grade+black",
    rating: 4.7,
    reviews: 456,
    category: "cases",
    inStock: true,
  },
  {
    id: "16",
    name: "3-in-1 Wireless Charger",
    price: 89.99,
    originalPrice: 119.99,
    image: "https://placehold.co/400x400?text=Premium+wireless+charging+station+for+phone+watch+earbuds+white+elegant",
    rating: 4.9,
    reviews: 523,
    category: "chargers",
    inStock: true,
    badge: "Bestseller",
  },
]

const categories = [
  { id: "cases", name: "Cases & Covers" },
  { id: "chargers", name: "Chargers" },
  { id: "audio", name: "Audio" },
  { id: "power-banks", name: "Power Banks" },
  { id: "cables", name: "Cables" },
  { id: "accessories", name: "Accessories" },
]

export default function ProductsPage() {
  const searchParams = useSearchParams()
  const categoryParam = searchParams?.get("category")

  const [searchQuery, setSearchQuery] = useState("")
  const [selectedCategories, setSelectedCategories] = useState<string[]>(categoryParam ? [categoryParam] : [])
  const [priceRange, setPriceRange] = useState([0, 200])
  const [minRating, setMinRating] = useState(0)
  const [sortBy, setSortBy] = useState("featured")
  const [showInStockOnly, setShowInStockOnly] = useState(false)

  const filteredAndSortedProducts = useMemo(() => {
    let filtered = [...allProducts]

    // Filter by search query
    if (searchQuery) {
      filtered = filtered.filter((product) => product.name.toLowerCase().includes(searchQuery.toLowerCase()))
    }

    // Filter by categories
    if (selectedCategories.length > 0) {
      filtered = filtered.filter((product) => selectedCategories.includes(product.category))
    }

    // Filter by price range
    filtered = filtered.filter((product) => product.price >= priceRange[0] && product.price <= priceRange[1])

    // Filter by rating
    if (minRating > 0) {
      filtered = filtered.filter((product) => product.rating >= minRating)
    }

    // Filter by stock
    if (showInStockOnly) {
      filtered = filtered.filter((product) => product.inStock)
    }

    // Sort products
    switch (sortBy) {
      case "price-low":
        filtered.sort((a, b) => a.price - b.price)
        break
      case "price-high":
        filtered.sort((a, b) => b.price - a.price)
        break
      case "rating":
        filtered.sort((a, b) => b.rating - a.rating)
        break
      case "newest":
        filtered.sort((a, b) => (b.badge === "New" ? 1 : 0) - (a.badge === "New" ? 1 : 0))
        break
      default:
        // Featured - keep original order with bestsellers first
        filtered.sort((a, b) => (b.badge === "Bestseller" ? 1 : 0) - (a.badge === "Bestseller" ? 1 : 0))
    }

    return filtered
  }, [searchQuery, selectedCategories, priceRange, minRating, sortBy, showInStockOnly])

  const toggleCategory = (categoryId: string) => {
    setSelectedCategories((prev) =>
      prev.includes(categoryId) ? prev.filter((id) => id !== categoryId) : [...prev, categoryId],
    )
  }

  const clearFilters = () => {
    setSearchQuery("")
    setSelectedCategories([])
    setPriceRange([0, 200])
    setMinRating(0)
    setShowInStockOnly(false)
    setSortBy("featured")
  }

  const FiltersContent = () => (
    <div className="space-y-6">
      {/* Categories */}
      <div>
        <h3 className="mb-3 font-semibold">Categories</h3>
        <div className="space-y-2">
          {categories.map((category) => (
            <div key={category.id} className="flex items-center space-x-2">
              <Checkbox
                id={category.id}
                checked={selectedCategories.includes(category.id)}
                onCheckedChange={() => toggleCategory(category.id)}
              />
              <Label htmlFor={category.id} className="text-sm font-normal cursor-pointer">
                {category.name}
              </Label>
            </div>
          ))}
        </div>
      </div>

      {/* Price Range */}
      <div>
        <div className="mb-3 flex items-center justify-between">
          <h3 className="font-semibold">Price Range</h3>
          <span className="text-sm text-muted-foreground">
            ${priceRange[0]} - ${priceRange[1]}
          </span>
        </div>
        <Slider min={0} max={200} step={10} value={priceRange} onValueChange={setPriceRange} className="mb-2" />
      </div>

      {/* Rating */}
      <div>
        <h3 className="mb-3 font-semibold">Minimum Rating</h3>
        <Select value={minRating.toString()} onValueChange={(value) => setMinRating(Number(value))}>
          <SelectTrigger>
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="0">All Ratings</SelectItem>
            <SelectItem value="4">4+ Stars</SelectItem>
            <SelectItem value="4.5">4.5+ Stars</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Availability */}
      <div>
        <div className="flex items-center space-x-2">
          <Checkbox
            id="in-stock"
            checked={showInStockOnly}
            onCheckedChange={(checked) => setShowInStockOnly(checked as boolean)}
          />
          <Label htmlFor="in-stock" className="text-sm font-normal cursor-pointer">
            In Stock Only
          </Label>
        </div>
      </div>

      {/* Clear Filters */}
      <Button variant="outline" onClick={clearFilters} className="w-full bg-transparent">
        Clear All Filters
      </Button>
    </div>
  )

  return (
    <div className="min-h-screen">
      <Header />
      <main className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="mb-2 text-3xl font-bold tracking-tight text-balance md:text-4xl">All Products</h1>
          <p className="text-muted-foreground text-pretty">Browse our complete collection of mobile accessories</p>
        </div>

        <div className="flex gap-8">
          {/* Desktop Filters Sidebar */}
          <aside className="hidden w-64 shrink-0 lg:block">
            <div className="sticky top-24 space-y-6 rounded-lg border bg-card p-6">
              <FiltersContent />
            </div>
          </aside>

          {/* Main Content */}
          <div className="flex-1">
            {/* Search and Sort Bar */}
            <div className="mb-6 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
              <div className="flex flex-1 gap-2">
                <Input
                  type="search"
                  placeholder="Search products..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="max-w-md"
                />
                {/* Mobile Filter Button */}
                <Sheet>
                  <SheetTrigger asChild>
                    <Button variant="outline" size="icon" className="lg:hidden bg-transparent">
                      <SlidersHorizontal className="h-4 w-4" />
                    </Button>
                  </SheetTrigger>
                  <SheetContent side="left" className="w-80 overflow-y-auto">
                    <SheetHeader>
                      <SheetTitle>Filters</SheetTitle>
                    </SheetHeader>
                    <div className="mt-6">
                      <FiltersContent />
                    </div>
                  </SheetContent>
                </Sheet>
              </div>

              <div className="flex items-center gap-2">
                <Label htmlFor="sort" className="text-sm whitespace-nowrap">
                  Sort by:
                </Label>
                <Select value={sortBy} onValueChange={setSortBy}>
                  <SelectTrigger id="sort" className="w-40">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="featured">Featured</SelectItem>
                    <SelectItem value="newest">Newest</SelectItem>
                    <SelectItem value="price-low">Price: Low to High</SelectItem>
                    <SelectItem value="price-high">Price: High to Low</SelectItem>
                    <SelectItem value="rating">Highest Rated</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            {/* Results Count */}
            <div className="mb-4 text-sm text-muted-foreground">
              Showing {filteredAndSortedProducts.length}{" "}
              {filteredAndSortedProducts.length === 1 ? "product" : "products"}
            </div>

            {/* Products Grid */}
            {filteredAndSortedProducts.length > 0 ? (
              <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
                {filteredAndSortedProducts.map((product) => (
                  <ProductCard key={product.id} product={product} />
                ))}
              </div>
            ) : (
              <div className="rounded-lg border bg-card p-12 text-center">
                <p className="text-lg font-medium">No products found</p>
                <p className="mt-2 text-sm text-muted-foreground">Try adjusting your filters</p>
                <Button variant="outline" onClick={clearFilters} className="mt-4 bg-transparent">
                  Clear Filters
                </Button>
              </div>
            )}
          </div>
        </div>
      </main>
      <Footer />
    </div>
  )
}
