"use client"

import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { useCart } from "@/hooks/use-cart"
import { useToast } from "@/hooks/use-toast"
import { Star, ShoppingCart, Heart, Share2, Truck, ShieldCheck, RefreshCw, Check } from "lucide-react"
import { useState } from "react"
import { ProductCard } from "@/components/product-card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Progress } from "@/components/ui/progress"

// Mock product data - in real app, this would come from a database
const productData = {
  "1": {
    id: "1",
    name: "Premium Silicone Case",
    price: 29.99,
    originalPrice: 39.99,
    images: [
      "https://placehold.co/800x800?text=Premium+matte+black+silicone+phone+case+with+camera+protection+modern+minimal+design",
      "https://placehold.co/800x800?text=Phone+case+side+view+showing+textured+grip+pattern+and+raised+edges",
      "https://placehold.co/800x800?text=Phone+case+back+view+with+precise+cutouts+for+camera+flash",
      "https://placehold.co/800x800?text=Phone+case+on+white+smartphone+showing+perfect+fit+and+coverage",
    ],
    rating: 4.8,
    reviews: 324,
    category: "Cases",
    inStock: true,
    description:
      "Protect your phone in style with our Premium Silicone Case. Made from high-quality liquid silicone, this case offers superior protection while maintaining a slim profile. The soft-touch finish provides excellent grip, and the raised edges protect your screen and camera from scratches.",
    features: [
      "Premium liquid silicone material",
      "Shock-absorbent design",
      "Raised edges for screen and camera protection",
      "Precise cutouts for all ports and buttons",
      "Wireless charging compatible",
      "Easy to install and remove",
    ],
    specifications: {
      Material: "Liquid Silicone",
      Compatibility: "iPhone 15 Pro Max",
      Colors: "Black, Navy, Pink, White",
      Weight: "45g",
      Thickness: "1.2mm",
    },
  },
}

const relatedProducts = [
  {
    id: "7",
    name: "Tempered Glass Screen Protector",
    price: 14.99,
    image:
      "https://placehold.co/400x400?text=Clear+tempered+glass+screen+protector+with+installation+kit+professional+quality",
    rating: 4.4,
    reviews: 523,
    category: "Accessories",
    inStock: true,
  },
  {
    id: "6",
    name: "Magnetic Car Mount",
    price: 24.99,
    image: "https://placehold.co/400x400?text=Sleek+black+magnetic+car+phone+holder+with+adjustable+arm+modern+design",
    rating: 4.6,
    reviews: 156,
    category: "Accessories",
    inStock: true,
  },
  {
    id: "2",
    name: "Wireless Charging Pad",
    price: 49.99,
    image: "https://placehold.co/400x400?text=Sleek+white+circular+wireless+charging+pad+with+LED+indicator+top+view",
    rating: 4.6,
    reviews: 189,
    category: "Chargers",
    inStock: true,
  },
  {
    id: "9",
    name: "Leather Wallet Case",
    price: 39.99,
    image: "https://placehold.co/400x400?text=Premium+brown+leather+wallet+phone+case+with+card+slots+elegant+design",
    rating: 4.7,
    reviews: 289,
    category: "Cases",
    inStock: true,
  },
]

const reviews = [
  {
    id: "1",
    author: "Sarah M.",
    rating: 5,
    date: "2 weeks ago",
    verified: true,
    title: "Best case I've ever owned",
    content:
      "This case feels amazing in hand. The silicone is super soft and provides excellent grip. It's protected my phone through several drops. Highly recommend!",
    helpful: 45,
  },
  {
    id: "2",
    author: "John D.",
    rating: 5,
    date: "1 month ago",
    verified: true,
    title: "Perfect fit and protection",
    content:
      "Fits my phone perfectly with easy access to all buttons. The raised edges around the camera and screen give me peace of mind. Worth every penny.",
    helpful: 32,
  },
  {
    id: "3",
    author: "Emma L.",
    rating: 4,
    date: "1 month ago",
    verified: true,
    title: "Great quality but attracts dust",
    content:
      "The case quality is excellent and it feels premium. My only complaint is that it attracts dust and lint easily. Otherwise, it's perfect.",
    helpful: 18,
  },
  {
    id: "4",
    author: "Michael R.",
    rating: 5,
    date: "2 months ago",
    verified: true,
    title: "Slim yet protective",
    content:
      "I love how this case adds minimal bulk while still providing great protection. The buttons are easy to press and it works perfectly with wireless charging.",
    helpful: 27,
  },
]

export default function ProductDetailPage({ params }: { params: { id: string } }) {
  const product = productData[params.id as keyof typeof productData] || productData["1"]
  const [selectedImage, setSelectedImage] = useState(0)
  const [quantity, setQuantity] = useState(1)
  const { addItem } = useCart()
  const { toast } = useToast()

  const handleAddToCart = () => {
    addItem({
      id: product.id,
      name: product.name,
      price: product.price,
      image: product.images[0],
      quantity,
    })
    toast({
      title: "Added to cart",
      description: `${quantity} x ${product.name} added to your cart.`,
    })
  }

  const discount = product.originalPrice
    ? Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100)
    : 0

  return (
    <div className="min-h-screen">
      <Header />
      <main className="container mx-auto px-4 py-8">
        {/* Product Details */}
        <div className="grid gap-8 lg:grid-cols-2 mb-16">
          {/* Images */}
          <div className="space-y-4">
            {/* Main Image */}
            <div className="aspect-square overflow-hidden rounded-2xl border bg-muted">
              <img
                src={product.images[selectedImage] || "/placeholder.svg"}
                alt={product.name}
                className="h-full w-full object-cover transition-transform hover:scale-105"
              />
            </div>
            {/* Thumbnails */}
            <div className="grid grid-cols-4 gap-4">
              {product.images.map((image, index) => (
                <button
                  key={index}
                  onClick={() => setSelectedImage(index)}
                  className={`aspect-square overflow-hidden rounded-lg border-2 transition-all ${
                    selectedImage === index ? "border-primary" : "border-transparent hover:border-muted-foreground/20"
                  }`}
                >
                  <img
                    src={image || "/placeholder.svg"}
                    alt={`${product.name} view ${index + 1}`}
                    className="h-full w-full object-cover"
                  />
                </button>
              ))}
            </div>
          </div>

          {/* Product Info */}
          <div className="space-y-6">
            <div>
              <Badge variant="secondary" className="mb-3">
                {product.category}
              </Badge>
              <h1 className="mb-3 text-3xl font-bold tracking-tight text-balance lg:text-4xl">{product.name}</h1>

              {/* Rating */}
              <div className="mb-4 flex items-center gap-4">
                <div className="flex items-center gap-1">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      className={`h-5 w-5 ${i < Math.floor(product.rating) ? "fill-yellow-400 text-yellow-400" : "text-muted-foreground"}`}
                    />
                  ))}
                </div>
                <span className="text-sm font-medium">{product.rating}</span>
                <a href="#reviews" className="text-sm text-primary hover:underline">
                  ({product.reviews} reviews)
                </a>
              </div>

              {/* Price */}
              <div className="flex items-baseline gap-3">
                <span className="text-4xl font-bold">${product.price}</span>
                {product.originalPrice && (
                  <>
                    <span className="text-xl text-muted-foreground line-through">${product.originalPrice}</span>
                    <Badge variant="destructive" className="text-white">
                      Save {discount}%
                    </Badge>
                  </>
                )}
              </div>
            </div>

            {/* Description */}
            <p className="text-muted-foreground leading-relaxed text-pretty">{product.description}</p>

            {/* Quantity & Actions */}
            <div className="space-y-4">
              <div>
                <label className="mb-2 block text-sm font-medium">Quantity</label>
                <div className="flex gap-2">
                  <div className="flex items-center">
                    <Button
                      variant="outline"
                      size="icon"
                      onClick={() => setQuantity(Math.max(1, quantity - 1))}
                      className="rounded-r-none bg-transparent"
                    >
                      -
                    </Button>
                    <div className="flex h-10 w-16 items-center justify-center border-y bg-muted font-medium">
                      {quantity}
                    </div>
                    <Button
                      variant="outline"
                      size="icon"
                      onClick={() => setQuantity(quantity + 1)}
                      className="rounded-l-none bg-transparent"
                    >
                      +
                    </Button>
                  </div>
                </div>
              </div>

              <div className="flex gap-3">
                <Button onClick={handleAddToCart} size="lg" className="flex-1 group">
                  <ShoppingCart className="mr-2 h-5 w-5 transition-transform group-hover:scale-110" />
                  Add to Cart
                </Button>
                <Button variant="outline" size="lg" className="bg-transparent">
                  <Heart className="h-5 w-5" />
                </Button>
                <Button variant="outline" size="lg" className="bg-transparent">
                  <Share2 className="h-5 w-5" />
                </Button>
              </div>
            </div>

            {/* Features */}
            <Card>
              <CardContent className="p-6">
                <div className="grid gap-4 sm:grid-cols-3">
                  <div className="flex items-start gap-3">
                    <Truck className="h-5 w-5 shrink-0 text-primary" />
                    <div>
                      <p className="font-medium">Free Delivery</p>
                      <p className="text-sm text-muted-foreground">On orders over $50</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <ShieldCheck className="h-5 w-5 shrink-0 text-primary" />
                    <div>
                      <p className="font-medium">Warranty</p>
                      <p className="text-sm text-muted-foreground">1-year coverage</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <RefreshCw className="h-5 w-5 shrink-0 text-primary" />
                    <div>
                      <p className="font-medium">Easy Returns</p>
                      <p className="text-sm text-muted-foreground">30-day policy</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Product Details Tabs */}
        <Tabs defaultValue="features" className="mb-16">
          <TabsList className="w-full justify-start">
            <TabsTrigger value="features">Features</TabsTrigger>
            <TabsTrigger value="specifications">Specifications</TabsTrigger>
            <TabsTrigger value="reviews">Reviews ({reviews.length})</TabsTrigger>
          </TabsList>

          <TabsContent value="features" className="mt-6">
            <Card>
              <CardContent className="p-6">
                <h3 className="mb-4 text-xl font-bold">Key Features</h3>
                <ul className="space-y-3">
                  {product.features.map((feature, index) => (
                    <li key={index} className="flex items-start gap-3">
                      <Check className="h-5 w-5 shrink-0 text-primary mt-0.5" />
                      <span>{feature}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="specifications" className="mt-6">
            <Card>
              <CardContent className="p-6">
                <h3 className="mb-4 text-xl font-bold">Technical Specifications</h3>
                <div className="grid gap-4 sm:grid-cols-2">
                  {Object.entries(product.specifications).map(([key, value]) => (
                    <div key={key} className="flex justify-between border-b pb-2">
                      <span className="font-medium">{key}</span>
                      <span className="text-muted-foreground">{value}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="reviews" id="reviews" className="mt-6">
            <Card>
              <CardContent className="p-6">
                <div className="mb-6 flex items-start justify-between">
                  <div>
                    <h3 className="mb-2 text-xl font-bold">Customer Reviews</h3>
                    <div className="flex items-center gap-3">
                      <div className="flex items-center gap-1">
                        {[...Array(5)].map((_, i) => (
                          <Star
                            key={i}
                            className={`h-4 w-4 ${i < Math.floor(product.rating) ? "fill-yellow-400 text-yellow-400" : "text-muted-foreground"}`}
                          />
                        ))}
                      </div>
                      <span className="text-sm font-medium">
                        {product.rating} out of 5 ({product.reviews} reviews)
                      </span>
                    </div>
                  </div>
                  <Button variant="outline" className="bg-transparent">
                    Write a Review
                  </Button>
                </div>

                {/* Rating Distribution */}
                <div className="mb-8 space-y-2">
                  {[5, 4, 3, 2, 1].map((stars) => (
                    <div key={stars} className="flex items-center gap-3">
                      <span className="w-16 text-sm">{stars} stars</span>
                      <Progress value={stars === 5 ? 75 : stars === 4 ? 20 : 5} className="flex-1" />
                      <span className="w-12 text-right text-sm text-muted-foreground">
                        {stars === 5 ? "75%" : stars === 4 ? "20%" : "5%"}
                      </span>
                    </div>
                  ))}
                </div>

                {/* Individual Reviews */}
                <div className="space-y-6">
                  {reviews.map((review) => (
                    <div key={review.id} className="border-t pt-6 first:border-0 first:pt-0">
                      <div className="mb-3 flex items-start justify-between">
                        <div className="flex items-start gap-3">
                          <Avatar>
                            <AvatarImage src="/placeholder.svg" />
                            <AvatarFallback>{review.author[0]}</AvatarFallback>
                          </Avatar>
                          <div>
                            <div className="flex items-center gap-2">
                              <p className="font-semibold">{review.author}</p>
                              {review.verified && (
                                <Badge variant="secondary" className="text-xs">
                                  Verified Purchase
                                </Badge>
                              )}
                            </div>
                            <div className="mt-1 flex items-center gap-2">
                              <div className="flex">
                                {[...Array(5)].map((_, i) => (
                                  <Star
                                    key={i}
                                    className={`h-3.5 w-3.5 ${i < review.rating ? "fill-yellow-400 text-yellow-400" : "text-muted-foreground"}`}
                                  />
                                ))}
                              </div>
                              <span className="text-xs text-muted-foreground">{review.date}</span>
                            </div>
                          </div>
                        </div>
                      </div>
                      <h4 className="mb-2 font-semibold">{review.title}</h4>
                      <p className="mb-3 text-muted-foreground leading-relaxed">{review.content}</p>
                      <div className="flex items-center gap-4 text-sm">
                        <button className="text-muted-foreground hover:text-foreground">
                          Helpful ({review.helpful})
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Related Products */}
        <div>
          <h2 className="mb-6 text-2xl font-bold">You May Also Like</h2>
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {relatedProducts.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        </div>
      </main>
      <Footer />
    </div>
  )
}
