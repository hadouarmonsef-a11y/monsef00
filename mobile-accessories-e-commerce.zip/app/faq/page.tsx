import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"
import { Card, CardContent } from "@/components/ui/card"

const faqs = [
  {
    category: "Orders & Payment",
    questions: [
      {
        question: "What payment methods do you accept?",
        answer:
          "We accept all major credit cards (Visa, Mastercard, American Express), PayPal, Payoneer, and Cash on Delivery. All transactions are secured with SSL encryption.",
      },
      {
        question: "Can I modify or cancel my order?",
        answer:
          "You can modify or cancel your order within 1 hour of placement. After this time, orders are processed and cannot be changed. Please contact our support team immediately if you need assistance.",
      },
      {
        question: "Do you offer international shipping?",
        answer:
          "Yes, we ship to most countries worldwide. Shipping costs and delivery times vary by location. You can see the exact cost and estimated delivery time during checkout.",
      },
    ],
  },
  {
    category: "Shipping & Delivery",
    questions: [
      {
        question: "How long does shipping take?",
        answer:
          "Standard shipping takes 3-5 business days within the US. Express shipping (1-2 business days) is available for an additional fee. International shipping times vary by destination.",
      },
      {
        question: "Is there free shipping?",
        answer:
          "Yes! We offer free standard shipping on all orders over $50 within the US. Orders under $50 have a flat shipping rate of $5.99.",
      },
      {
        question: "How can I track my order?",
        answer:
          "Once your order ships, you'll receive a tracking number via email. You can also track your order anytime on our Track Order page using your order number and email address.",
      },
    ],
  },
  {
    category: "Returns & Refunds",
    questions: [
      {
        question: "What is your return policy?",
        answer:
          "We offer a 30-day return policy on all products. Items must be unused, in original packaging, and in the same condition as received. Return shipping is free for defective items.",
      },
      {
        question: "How do I return an item?",
        answer:
          "Contact our support team to initiate a return. We'll provide you with a return shipping label and instructions. Once we receive and inspect your return, we'll process your refund within 5-7 business days.",
      },
      {
        question: "Do you offer exchanges?",
        answer:
          "Yes, we're happy to exchange items for different colors, sizes, or models. Contact our support team to arrange an exchange. Exchanges are processed faster than returns and refunds.",
      },
    ],
  },
  {
    category: "Products & Warranty",
    questions: [
      {
        question: "Are your products genuine?",
        answer:
          "Yes, all our products are 100% genuine and sourced directly from authorized manufacturers and distributors. We guarantee authenticity on every item we sell.",
      },
      {
        question: "Do products come with a warranty?",
        answer:
          "Most of our products come with a 1-year manufacturer warranty covering defects in materials and workmanship. Some premium products may have extended warranties. Check individual product pages for specific warranty information.",
      },
      {
        question: "Can I get a bulk discount?",
        answer:
          "Yes! We offer special pricing for bulk orders. Please contact our sales team with your requirements, and we'll provide a custom quote for orders of 10+ units of the same product.",
      },
    ],
  },
]

export default function FAQPage() {
  return (
    <div className="min-h-screen">
      <Header />
      <main className="container mx-auto px-4 py-8">
        <div className="mb-8 text-center">
          <h1 className="mb-3 text-3xl font-bold tracking-tight text-balance md:text-4xl">
            Frequently Asked Questions
          </h1>
          <p className="text-muted-foreground text-pretty">
            Find answers to common questions about our products and services
          </p>
        </div>

        <div className="mx-auto max-w-3xl space-y-8">
          {faqs.map((category, index) => (
            <Card key={index}>
              <CardContent className="p-6">
                <h2 className="mb-4 text-xl font-bold">{category.category}</h2>
                <Accordion type="single" collapsible>
                  {category.questions.map((faq, faqIndex) => (
                    <AccordionItem key={faqIndex} value={`item-${index}-${faqIndex}`}>
                      <AccordionTrigger className="text-left">{faq.question}</AccordionTrigger>
                      <AccordionContent className="text-muted-foreground leading-relaxed">
                        {faq.answer}
                      </AccordionContent>
                    </AccordionItem>
                  ))}
                </Accordion>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="mt-12 text-center">
          <p className="mb-4 text-muted-foreground">Still have questions?</p>
          <a href="/contact" className="text-primary hover:underline font-medium">
            Contact our support team
          </a>
        </div>
      </main>
      <Footer />
    </div>
  )
}
