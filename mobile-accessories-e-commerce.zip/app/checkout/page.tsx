"use client"

import type React from "react"

import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Checkbox } from "@/components/ui/checkbox"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useCart } from "@/hooks/use-cart"
import { CreditCard, Banknote, CheckCircle2, Lock } from "lucide-react"
import { useState } from "react"
import { useRouter } from "next/navigation"
import { useToast } from "@/hooks/use-toast"

export default function CheckoutPage() {
  const { items, cartTotal, clearCart } = useCart()
  const router = useRouter()
  const { toast } = useToast()

  const [paymentMethod, setPaymentMethod] = useState("card")
  const [saveInfo, setSaveInfo] = useState(false)
  const [isProcessing, setIsProcessing] = useState(false)

  const shipping = cartTotal > 50 ? 0 : 5.99
  const tax = cartTotal * 0.1
  const total = cartTotal + shipping + tax

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsProcessing(true)

    // Simulate payment processing
    await new Promise((resolve) => setTimeout(resolve, 2000))

    // Clear cart and redirect to success page
    clearCart()
    toast({
      title: "Order placed successfully!",
      description: "Thank you for your purchase. You will receive a confirmation email shortly.",
    })
    router.push("/order-confirmation")
  }

  if (items.length === 0) {
    router.push("/cart")
    return null
  }

  return (
    <div className="min-h-screen">
      <Header />
      <main className="container mx-auto px-4 py-8">
        <h1 className="mb-8 text-3xl font-bold tracking-tight text-balance">Checkout</h1>

        <form onSubmit={handleSubmit}>
          <div className="grid gap-8 lg:grid-cols-3">
            {/* Left Column - Forms */}
            <div className="lg:col-span-2 space-y-6">
              {/* Contact Information */}
              <Card>
                <CardHeader>
                  <CardTitle>Contact Information</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid gap-4 sm:grid-cols-2">
                    <div>
                      <Label htmlFor="email">Email</Label>
                      <Input id="email" type="email" placeholder="your@email.com" required />
                    </div>
                    <div>
                      <Label htmlFor="phone">Phone Number</Label>
                      <Input id="phone" type="tel" placeholder="+1 (555) 000-0000" required />
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Shipping Address */}
              <Card>
                <CardHeader>
                  <CardTitle>Shipping Address</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid gap-4 sm:grid-cols-2">
                    <div>
                      <Label htmlFor="firstName">First Name</Label>
                      <Input id="firstName" placeholder="John" required />
                    </div>
                    <div>
                      <Label htmlFor="lastName">Last Name</Label>
                      <Input id="lastName" placeholder="Doe" required />
                    </div>
                  </div>
                  <div>
                    <Label htmlFor="address">Street Address</Label>
                    <Input id="address" placeholder="123 Main St, Apt 4B" required />
                  </div>
                  <div className="grid gap-4 sm:grid-cols-3">
                    <div>
                      <Label htmlFor="city">City</Label>
                      <Input id="city" placeholder="New York" required />
                    </div>
                    <div>
                      <Label htmlFor="state">State</Label>
                      <Select required>
                        <SelectTrigger id="state">
                          <SelectValue placeholder="Select" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="ny">New York</SelectItem>
                          <SelectItem value="ca">California</SelectItem>
                          <SelectItem value="tx">Texas</SelectItem>
                          <SelectItem value="fl">Florida</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label htmlFor="zip">ZIP Code</Label>
                      <Input id="zip" placeholder="10001" required />
                    </div>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="save-info"
                      checked={saveInfo}
                      onCheckedChange={(checked) => setSaveInfo(checked as boolean)}
                    />
                    <Label htmlFor="save-info" className="text-sm font-normal cursor-pointer">
                      Save this information for next time
                    </Label>
                  </div>
                </CardContent>
              </Card>

              {/* Payment Method */}
              <Card>
                <CardHeader>
                  <CardTitle>Payment Method</CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  <RadioGroup value={paymentMethod} onValueChange={setPaymentMethod}>
                    {/* Credit/Debit Card */}
                    <div className="flex items-start space-x-3 rounded-lg border p-4">
                      <RadioGroupItem value="card" id="card" className="mt-1" />
                      <div className="flex-1">
                        <Label htmlFor="card" className="flex items-center gap-2 cursor-pointer">
                          <CreditCard className="h-5 w-5" />
                          <span className="font-medium">Credit / Debit Card</span>
                        </Label>
                        <div className="mt-2 flex gap-2">
                          <div className="rounded border bg-background px-2 py-1 text-xs">Visa</div>
                          <div className="rounded border bg-background px-2 py-1 text-xs">Mastercard</div>
                          <div className="rounded border bg-background px-2 py-1 text-xs">Amex</div>
                        </div>
                        {paymentMethod === "card" && (
                          <div className="mt-4 space-y-3">
                            <div>
                              <Label htmlFor="cardNumber">Card Number</Label>
                              <Input id="cardNumber" placeholder="1234 5678 9012 3456" required />
                            </div>
                            <div className="grid gap-3 sm:grid-cols-3">
                              <div className="sm:col-span-2">
                                <Label htmlFor="cardExpiry">Expiry Date</Label>
                                <Input id="cardExpiry" placeholder="MM / YY" required />
                              </div>
                              <div>
                                <Label htmlFor="cardCvv">CVV</Label>
                                <Input id="cardCvv" placeholder="123" maxLength={4} required />
                              </div>
                            </div>
                            <div>
                              <Label htmlFor="cardName">Cardholder Name</Label>
                              <Input id="cardName" placeholder="Name on card" required />
                            </div>
                          </div>
                        )}
                      </div>
                    </div>

                    {/* PayPal */}
                    <div className="flex items-start space-x-3 rounded-lg border p-4">
                      <RadioGroupItem value="paypal" id="paypal" className="mt-1" />
                      <div className="flex-1">
                        <Label htmlFor="paypal" className="flex items-center gap-2 cursor-pointer">
                          <div className="flex h-5 w-5 items-center justify-center rounded-full bg-blue-600 text-xs font-bold text-white">
                            P
                          </div>
                          <span className="font-medium">PayPal</span>
                        </Label>
                        <p className="mt-1 text-sm text-muted-foreground">
                          You will be redirected to PayPal to complete your purchase
                        </p>
                      </div>
                    </div>

                    {/* Payoneer */}
                    <div className="flex items-start space-x-3 rounded-lg border p-4">
                      <RadioGroupItem value="payoneer" id="payoneer" className="mt-1" />
                      <div className="flex-1">
                        <Label htmlFor="payoneer" className="flex items-center gap-2 cursor-pointer">
                          <div className="flex h-5 w-5 items-center justify-center rounded-full bg-orange-600 text-xs font-bold text-white">
                            P
                          </div>
                          <span className="font-medium">Payoneer</span>
                        </Label>
                        <p className="mt-1 text-sm text-muted-foreground">
                          You will be redirected to Payoneer to complete your purchase
                        </p>
                      </div>
                    </div>

                    {/* Cash on Delivery */}
                    <div className="flex items-start space-x-3 rounded-lg border p-4">
                      <RadioGroupItem value="cod" id="cod" className="mt-1" />
                      <div className="flex-1">
                        <Label htmlFor="cod" className="flex items-center gap-2 cursor-pointer">
                          <Banknote className="h-5 w-5" />
                          <span className="font-medium">Cash on Delivery</span>
                        </Label>
                        <p className="mt-1 text-sm text-muted-foreground">Pay when you receive your order</p>
                      </div>
                    </div>
                  </RadioGroup>

                  {/* Security Notice */}
                  <div className="flex items-start gap-3 rounded-lg bg-muted p-4">
                    <Lock className="h-5 w-5 shrink-0 text-primary" />
                    <div className="text-sm">
                      <p className="font-medium">Secure Payment</p>
                      <p className="text-muted-foreground">
                        Your payment information is encrypted and secure. We never store your card details.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Right Column - Order Summary */}
            <div className="lg:col-span-1">
              <Card className="sticky top-24">
                <CardHeader>
                  <CardTitle>Order Summary</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {/* Order Items */}
                  <div className="space-y-3 border-b pb-4">
                    {items.map((item) => (
                      <div key={item.id} className="flex gap-3">
                        <div className="relative h-16 w-16 shrink-0 overflow-hidden rounded border">
                          <img
                            src={item.image || "/placeholder.svg"}
                            alt={item.name}
                            className="h-full w-full object-cover"
                          />
                          <div className="absolute -right-2 -top-2 flex h-5 w-5 items-center justify-center rounded-full bg-primary text-xs font-bold text-primary-foreground">
                            {item.quantity}
                          </div>
                        </div>
                        <div className="flex-1">
                          <p className="text-sm font-medium line-clamp-2">{item.name}</p>
                          <p className="text-sm text-muted-foreground">${item.price}</p>
                        </div>
                      </div>
                    ))}
                  </div>

                  {/* Price Breakdown */}
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Subtotal</span>
                      <span className="font-medium">${cartTotal.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Shipping</span>
                      <span className="font-medium">{shipping === 0 ? "FREE" : `$${shipping.toFixed(2)}`}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Tax</span>
                      <span className="font-medium">${tax.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between border-t pt-2 text-lg font-bold">
                      <span>Total</span>
                      <span>${total.toFixed(2)}</span>
                    </div>
                  </div>

                  {/* Place Order Button */}
                  <Button type="submit" className="w-full" size="lg" disabled={isProcessing}>
                    {isProcessing ? (
                      "Processing..."
                    ) : (
                      <>
                        <CheckCircle2 className="mr-2 h-5 w-5" />
                        Place Order
                      </>
                    )}
                  </Button>

                  <p className="text-center text-xs text-muted-foreground">
                    By placing your order, you agree to our{" "}
                    <a href="/terms" className="underline hover:text-foreground">
                      terms and conditions
                    </a>
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>
        </form>
      </main>
      <Footer />
    </div>
  )
}
