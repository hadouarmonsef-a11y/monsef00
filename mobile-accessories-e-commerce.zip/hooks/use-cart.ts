"use client"

import { create } from "zustand"
import { persist } from "zustand/middleware"

export interface CartItem {
  id: string
  name: string
  price: number
  image: string
  quantity: number
}

interface CartStore {
  items: CartItem[]
  addItem: (item: CartItem) => void
  removeItem: (id: string) => void
  updateQuantity: (id: string, quantity: number) => void
  clearCart: () => void
  cartCount: number
  cartTotal: number
}

export const useCart = create<CartStore>()(
  persist(
    (set, get) => ({
      items: [],
      cartCount: 0,
      cartTotal: 0,

      addItem: (item) => {
        const items = get().items
        const existingItem = items.find((i) => i.id === item.id)

        if (existingItem) {
          set({
            items: items.map((i) => (i.id === item.id ? { ...i, quantity: i.quantity + item.quantity } : i)),
          })
        } else {
          set({ items: [...items, item] })
        }

        // Update cart count and total
        const newItems = get().items
        set({
          cartCount: newItems.reduce((acc, item) => acc + item.quantity, 0),
          cartTotal: newItems.reduce((acc, item) => acc + item.price * item.quantity, 0),
        })
      },

      removeItem: (id) => {
        set({ items: get().items.filter((item) => item.id !== id) })

        // Update cart count and total
        const newItems = get().items
        set({
          cartCount: newItems.reduce((acc, item) => acc + item.quantity, 0),
          cartTotal: newItems.reduce((acc, item) => acc + item.price * item.quantity, 0),
        })
      },

      updateQuantity: (id, quantity) => {
        if (quantity <= 0) {
          get().removeItem(id)
          return
        }

        set({
          items: get().items.map((item) => (item.id === id ? { ...item, quantity } : item)),
        })

        // Update cart count and total
        const newItems = get().items
        set({
          cartCount: newItems.reduce((acc, item) => acc + item.quantity, 0),
          cartTotal: newItems.reduce((acc, item) => acc + item.price * item.quantity, 0),
        })
      },

      clearCart: () => {
        set({ items: [], cartCount: 0, cartTotal: 0 })
      },
    }),
    {
      name: "cart-storage",
    },
  ),
)
