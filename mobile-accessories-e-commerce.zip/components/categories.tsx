import Link from "next/link"
import { Card, CardContent } from "@/components/ui/card"
import { Smartphone, Headphones, Battery, Cable, ShieldCheck, Zap } from "lucide-react"

const categories = [
  {
    name: "Cases & Covers",
    icon: ShieldCheck,
    href: "/products?category=cases",
    count: "500+ items",
  },
  {
    name: "Chargers",
    icon: Zap,
    href: "/products?category=chargers",
    count: "300+ items",
  },
  {
    name: "Audio",
    icon: Headphones,
    href: "/products?category=audio",
    count: "400+ items",
  },
  {
    name: "Power Banks",
    icon: Battery,
    href: "/products?category=power-banks",
    count: "200+ items",
  },
  {
    name: "Cables",
    icon: Cable,
    href: "/products?category=cables",
    count: "250+ items",
  },
  {
    name: "Accessories",
    icon: Smartphone,
    href: "/products?category=accessories",
    count: "350+ items",
  },
]

export function Categories() {
  return (
    <section className="py-16 md:py-20">
      <div className="container mx-auto px-4">
        <div className="mb-12 text-center">
          <h2 className="text-3xl font-bold tracking-tight text-balance md:text-4xl">Shop by Category</h2>
          <p className="mt-3 text-muted-foreground text-pretty">Find exactly what you need for your mobile device</p>
        </div>

        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6">
          {categories.map((category) => (
            <Link key={category.name} href={category.href}>
              <Card className="h-full transition-all hover:shadow-lg hover:border-primary/50 group">
                <CardContent className="flex flex-col items-center justify-center p-6 text-center">
                  <div className="mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-primary/10 transition-colors group-hover:bg-primary/20">
                    <category.icon className="h-8 w-8 text-primary" />
                  </div>
                  <h3 className="font-semibold mb-1">{category.name}</h3>
                  <p className="text-xs text-muted-foreground">{category.count}</p>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>
      </div>
    </section>
  )
}
