import { Button } from "@/components/ui/button"
import Link from "next/link"
import { Truck, ShieldCheck, HeadphonesIcon, RefreshCw } from "lucide-react"

export function PromoSection() {
  return (
    <section className="py-16 md:py-20">
      <div className="container mx-auto px-4">
        {/* Features */}
        <div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-4 mb-16">
          <div className="flex flex-col items-center text-center">
            <div className="mb-4 flex h-14 w-14 items-center justify-center rounded-full bg-primary/10">
              <Truck className="h-7 w-7 text-primary" />
            </div>
            <h3 className="mb-2 font-semibold">Fast Delivery</h3>
            <p className="text-sm text-muted-foreground leading-relaxed">Free shipping on orders over $50</p>
          </div>
          <div className="flex flex-col items-center text-center">
            <div className="mb-4 flex h-14 w-14 items-center justify-center rounded-full bg-primary/10">
              <ShieldCheck className="h-7 w-7 text-primary" />
            </div>
            <h3 className="mb-2 font-semibold">Secure Payment</h3>
            <p className="text-sm text-muted-foreground leading-relaxed">100% secure transactions</p>
          </div>
          <div className="flex flex-col items-center text-center">
            <div className="mb-4 flex h-14 w-14 items-center justify-center rounded-full bg-primary/10">
              <HeadphonesIcon className="h-7 w-7 text-primary" />
            </div>
            <h3 className="mb-2 font-semibold">24/7 Support</h3>
            <p className="text-sm text-muted-foreground leading-relaxed">Always here to help you</p>
          </div>
          <div className="flex flex-col items-center text-center">
            <div className="mb-4 flex h-14 w-14 items-center justify-center rounded-full bg-primary/10">
              <RefreshCw className="h-7 w-7 text-primary" />
            </div>
            <h3 className="mb-2 font-semibold">Easy Returns</h3>
            <p className="text-sm text-muted-foreground leading-relaxed">30-day return policy</p>
          </div>
        </div>

        {/* CTA Banner */}
        <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-primary to-primary/80 p-8 md:p-12">
          <div className="relative z-10 mx-auto max-w-3xl text-center text-primary-foreground">
            <h2 className="mb-4 text-3xl font-bold tracking-tight text-balance md:text-4xl">
              Get 30% Off Your First Order
            </h2>
            <p className="mb-6 text-lg opacity-90 leading-relaxed text-pretty">
              Sign up now and receive an exclusive discount on your first purchase. Plus, stay updated with our latest
              deals and new arrivals.
            </p>
            <Button size="lg" variant="secondary" asChild>
              <Link href="/products">Shop Now</Link>
            </Button>
          </div>
          <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGRlZnM+PHBhdHRlcm4gaWQ9ImdyaWQiIHdpZHRoPSI2MCIgaGVpZ2h0PSI2MCIgcGF0dGVyblVuaXRzPSJ1c2VyU3BhY2VPblVzZSI+PHBhdGggZD0iTSAxMCAwIEwgMCAwIDAgMTAiIGZpbGw9Im5vbmUiIHN0cm9rZT0id2hpdGUiIHN0cm9rZS13aWR0aD0iMSIgb3BhY2l0eT0iMC4xIi8+PC9wYXR0ZXJuPjwvZGVmcz48cmVjdCB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiBmaWxsPSJ1cmwoI2dyaWQpIi8+PC9zdmc+')] opacity-20"></div>
        </div>
      </div>
    </section>
  )
}
