import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ArrowRight } from "lucide-react"

export function Hero() {
  return (
    <section className="relative overflow-hidden border-b bg-gradient-to-br from-background via-background to-muted/20">
      <div className="container mx-auto px-4 py-20 md:py-28">
        <div className="grid gap-8 lg:grid-cols-2 lg:gap-12 items-center">
          {/* Content */}
          <div className="space-y-6">
            <div className="inline-block rounded-full border bg-muted px-4 py-1.5 text-sm font-medium">
              New Arrivals Available
            </div>
            <h1 className="text-4xl font-bold leading-tight tracking-tight text-balance md:text-5xl lg:text-6xl">
              Premium Mobile Accessories
            </h1>
            <p className="text-lg text-muted-foreground leading-relaxed text-pretty max-w-2xl">
              Discover our curated collection of high-quality phone cases, chargers, audio devices, and more. Enhance
              your mobile experience with style and functionality.
            </p>
            <div className="flex flex-col gap-3 sm:flex-row">
              <Button size="lg" asChild className="group">
                <Link href="/products">
                  Shop Now
                  <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
                </Link>
              </Button>
              <Button size="lg" variant="outline" asChild>
                <Link href="/products?filter=new">View New Arrivals</Link>
              </Button>
            </div>
            <div className="flex gap-8 pt-4">
              <div>
                <div className="text-3xl font-bold">5000+</div>
                <div className="text-sm text-muted-foreground">Products</div>
              </div>
              <div>
                <div className="text-3xl font-bold">50K+</div>
                <div className="text-sm text-muted-foreground">Happy Customers</div>
              </div>
              <div>
                <div className="text-3xl font-bold">4.8</div>
                <div className="text-sm text-muted-foreground">Rating</div>
              </div>
            </div>
          </div>

          {/* Hero Image */}
          <div className="relative">
            <div className="relative aspect-square overflow-hidden rounded-2xl">
              <img
                src="https://placehold.co/800x800?text=Premium+wireless+earbuds+in+sleek+charging+case+with+modern+minimalist+design+on+clean+white+background"
                alt="Premium wireless earbuds in sleek charging case with modern minimalist design on clean white background"
                className="h-full w-full object-cover"
              />
            </div>
            {/* Floating badges */}
            <div className="absolute -left-4 top-20 rounded-xl bg-background p-4 shadow-lg border">
              <div className="text-2xl font-bold text-primary">30%</div>
              <div className="text-xs text-muted-foreground">OFF</div>
            </div>
            <div className="absolute -right-4 bottom-20 rounded-xl bg-background p-4 shadow-lg border">
              <div className="text-xs text-muted-foreground mb-1">Free Shipping</div>
              <div className="text-sm font-semibold">Orders Over $50</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
