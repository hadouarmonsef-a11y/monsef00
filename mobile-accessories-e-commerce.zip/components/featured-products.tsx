"use client"

import { ProductCard } from "@/components/product-card"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { ArrowRight } from "lucide-react"

// Mock products data
const featuredProducts = [
  {
    id: "1",
    name: "Premium Silicone Case",
    price: 29.99,
    originalPrice: 39.99,
    image:
      "https://placehold.co/400x400?text=Premium+matte+black+silicone+phone+case+with+camera+protection+modern+minimal+design",
    rating: 4.8,
    reviews: 324,
    category: "Cases",
    inStock: true,
  },
  {
    id: "2",
    name: "Wireless Charging Pad",
    price: 49.99,
    image: "https://placehold.co/400x400?text=Sleek+white+circular+wireless+charging+pad+with+LED+indicator+top+view",
    rating: 4.6,
    reviews: 189,
    category: "Chargers",
    inStock: true,
  },
  {
    id: "3",
    name: "True Wireless Earbuds",
    price: 79.99,
    originalPrice: 99.99,
    image:
      "https://placehold.co/400x400?text=Modern+black+wireless+earbuds+with+charging+case+premium+quality+on+white+background",
    rating: 4.9,
    reviews: 567,
    category: "Audio",
    inStock: true,
    badge: "Bestseller",
  },
  {
    id: "4",
    name: "20000mAh Power Bank",
    price: 59.99,
    image:
      "https://placehold.co/400x400?text=Compact+gray+portable+power+bank+with+dual+USB+ports+LED+display+professional",
    rating: 4.7,
    reviews: 412,
    category: "Power Banks",
    inStock: true,
  },
  {
    id: "5",
    name: "USB-C Fast Charging Cable",
    price: 19.99,
    image:
      "https://placehold.co/400x400?text=Braided+black+USB+C+charging+cable+coiled+on+white+surface+durable+premium",
    rating: 4.5,
    reviews: 298,
    category: "Cables",
    inStock: true,
  },
  {
    id: "6",
    name: "Magnetic Car Mount",
    price: 24.99,
    image: "https://placehold.co/400x400?text=Sleek+black+magnetic+car+phone+holder+with+adjustable+arm+modern+design",
    rating: 4.6,
    reviews: 156,
    category: "Accessories",
    inStock: true,
  },
  {
    id: "7",
    name: "Tempered Glass Screen Protector",
    price: 14.99,
    image:
      "https://placehold.co/400x400?text=Clear+tempered+glass+screen+protector+with+installation+kit+professional+quality",
    rating: 4.4,
    reviews: 523,
    category: "Accessories",
    inStock: true,
  },
  {
    id: "8",
    name: "Bluetooth Speaker",
    price: 69.99,
    originalPrice: 89.99,
    image:
      "https://placehold.co/400x400?text=Compact+cylindrical+waterproof+bluetooth+speaker+in+matte+black+modern+style",
    rating: 4.8,
    reviews: 234,
    category: "Audio",
    inStock: true,
    badge: "New",
  },
]

export function FeaturedProducts() {
  return (
    <section className="py-16 md:py-20 bg-muted/30">
      <div className="container mx-auto px-4">
        <div className="mb-12 flex items-end justify-between">
          <div>
            <h2 className="text-3xl font-bold tracking-tight text-balance md:text-4xl">Featured Products</h2>
            <p className="mt-3 text-muted-foreground text-pretty">Handpicked essentials for your mobile lifestyle</p>
          </div>
          <Button variant="ghost" asChild className="hidden sm:inline-flex group">
            <Link href="/products">
              View All
              <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
            </Link>
          </Button>
        </div>

        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {featuredProducts.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>

        <div className="mt-12 text-center sm:hidden">
          <Button asChild className="w-full group">
            <Link href="/products">
              View All Products
              <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
            </Link>
          </Button>
        </div>
      </div>
    </section>
  )
}
