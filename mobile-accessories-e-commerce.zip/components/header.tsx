"use client"

import Link from "next/link"
import { ShoppingCart, Search, User, Menu, X } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { useState } from "react"
import { useCart } from "@/hooks/use-cart"

export function Header() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)
  const { cartCount } = useCart()

  return (
    <header className="sticky top-0 z-50 border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container mx-auto px-4">
        {/* Top bar */}
        <div className="flex h-16 items-center justify-between gap-4">
          {/* Logo */}
          <Link href="/" className="flex items-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary">
              <span className="text-lg font-bold text-primary-foreground">M</span>
            </div>
            <span className="hidden text-xl font-bold sm:inline-block">MobileHub</span>
          </Link>

          {/* Search bar - desktop */}
          <div className="hidden flex-1 max-w-xl md:block">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input type="search" placeholder="Search for products..." className="w-full pl-10" />
            </div>
          </div>

          {/* Actions */}
          <div className="flex items-center gap-2">
            <Button variant="ghost" size="icon" className="hidden md:inline-flex">
              <User className="h-5 w-5" />
            </Button>
            <Link href="/cart">
              <Button variant="ghost" size="icon" className="relative">
                <ShoppingCart className="h-5 w-5" />
                {cartCount > 0 && (
                  <span className="absolute -right-1 -top-1 flex h-5 w-5 items-center justify-center rounded-full bg-primary text-xs font-bold text-primary-foreground">
                    {cartCount}
                  </span>
                )}
              </Button>
            </Link>
            <Button
              variant="ghost"
              size="icon"
              className="md:hidden"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            >
              {mobileMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </Button>
          </div>
        </div>

        {/* Navigation */}
        <nav className="hidden border-t py-3 md:block">
          <ul className="flex items-center gap-8 text-sm">
            <li>
              <Link href="/products" className="font-medium hover:text-primary">
                All Products
              </Link>
            </li>
            <li>
              <Link href="/products?category=cases" className="hover:text-primary">
                Cases & Covers
              </Link>
            </li>
            <li>
              <Link href="/products?category=chargers" className="hover:text-primary">
                Chargers
              </Link>
            </li>
            <li>
              <Link href="/products?category=audio" className="hover:text-primary">
                Audio
              </Link>
            </li>
            <li>
              <Link href="/products?category=power-banks" className="hover:text-primary">
                Power Banks
              </Link>
            </li>
            <li>
              <Link href="/products?category=accessories" className="hover:text-primary">
                Accessories
              </Link>
            </li>
          </ul>
        </nav>

        {/* Mobile menu */}
        {mobileMenuOpen && (
          <div className="border-t py-4 md:hidden">
            <div className="mb-4">
              <Input type="search" placeholder="Search products..." className="w-full" />
            </div>
            <nav className="space-y-3">
              <Link href="/products" className="block py-2 font-medium hover:text-primary">
                All Products
              </Link>
              <Link href="/products?category=cases" className="block py-2 hover:text-primary">
                Cases & Covers
              </Link>
              <Link href="/products?category=chargers" className="block py-2 hover:text-primary">
                Chargers
              </Link>
              <Link href="/products?category=audio" className="block py-2 hover:text-primary">
                Audio
              </Link>
              <Link href="/products?category=power-banks" className="block py-2 hover:text-primary">
                Power Banks
              </Link>
              <Link href="/products?category=accessories" className="block py-2 hover:text-primary">
                Accessories
              </Link>
              <Link href="/account" className="block py-2 hover:text-primary">
                My Account
              </Link>
            </nav>
          </div>
        )}
      </div>
    </header>
  )
}
